$(document).ready(function() {
   // initiate tool tip
	$('.normaltip').aToolTip();
 });